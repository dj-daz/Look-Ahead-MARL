close all
clear

load('20A20T.mat')

length = 101;
n = 5;
k = 4;

ks = {'1','5','10','20'};
ns = {'0','1','2','3','4'};
alpha = 0.05;

%% For controlled K varied N

delay_Ks = zeros(length,n,k);
ltime_Ks = zeros(length,n,k);
reward_Ks = zeros(length,n,k);
tasks_Ks = zeros(length,n,k);
travel_Ks = zeros(length,n,k);

for i = 1:k
    
    row = 2;
    
    for j = 1:n
        delay_Ks(:,j,i) = exp_smooth(alpha,delay_K(row:(row+length-1),i+1));
        ltime_Ks(:,j,i) = exp_smooth(alpha,ltime_K(row:(row+length-1),i+1));
        reward_Ks(:,j,i) = exp_smooth(alpha,reward_K(row:(row+length-1),i+1));
        tasks_Ks(:,j,i) = exp_smooth(alpha,tasks_K(row:(row+length-1),i+1));
        travel_Ks(:,j,i) = exp_smooth(alpha,travel_K(row:(row+length-1),i+1));
        
        row = row + length;
    end
    
end

for i = 1:k
    figure
    for j = 1:n
        subplot(2,2,1)
        plot(delay_K(2:length+1,1),delay_Ks(:,j,i))
        hold on
    end
    legend('N0', 'N1', 'N2', 'N3', 'N4')
    hold off
    ylabel('Delay (iterations)')
    xlabel('Episodes')
    
    for j = 1:n
        subplot(2,2,2)
        plot(delay_K(2:length+1,1),ltime_Ks(:,j,i))
        hold on
    end
    legend('N0', 'N1', 'N2', 'N3', 'N4')
    hold off
    ylabel('Leadtime (iterations)')
    xlabel('Episodes')
    
    for j = 1:n
        subplot(2,2,3)
        plot(delay_K(2:length+1,1),reward_Ks(:,j,i))
        hold on
    end
    legend('N0', 'N1', 'N2', 'N3', 'N4')
    hold off
    ylabel('Reward')
    xlabel('Episodes')
    
    for j = 1:n
        subplot(2,2,4)
        plot(delay_K(2:length+1,1),travel_Ks(:,j,i))
        hold on
    end
    legend('N0', 'N1', 'N2', 'N3', 'N4')
    hold off
    ylabel('Normalised travel distance')
    xlabel('Episodes')
    
    pol = strcat('Metrics for 20 agents and 20 tasks with controlled look-ahead parameter k = ',ks{i});
    sgtitle(pol)
end


%% For controlled N varied K

delay_Ns = zeros(length,k,n);
ltime_Ns = zeros(length,k,n);
reward_Ns = zeros(length,k,n);
tasks_Ns = zeros(length,k,n);
travel_Ns = zeros(length,k,n);

for i = 1:n
    
    row = 2;
    
    for j = 1:k
        delay_Ns(:,j,i) = exp_smooth(alpha,delay_N(row:(row+length-1),i+1));
        ltime_Ns(:,j,i) = exp_smooth(alpha,ltime_N(row:(row+length-1),i+1));
        reward_Ns(:,j,i) = exp_smooth(alpha,reward_N(row:(row+length-1),i+1));
        tasks_Ns(:,j,i) = exp_smooth(alpha,tasks_N(row:(row+length-1),i+1));
        travel_Ns(:,j,i) = exp_smooth(alpha,travel_N(row:(row+length-1),i+1));
        
        row = row + length;
    end
    
end

for i = 1:n
    figure
    for j = 1:k
        subplot(2,2,1)
        plot(delay_N(2:length+1,1),delay_Ns(:,j,i))
        hold on
    end
    legend('K1', 'K5', 'K10', 'K20')
    hold off
    ylabel('Delay (iterations)')
    xlabel('Episodes')
    
    for j = 1:k
        subplot(2,2,2)
        plot(delay_N(2:length+1,1),ltime_Ns(:,j,i))
        hold on
    end
    legend('K1', 'K5', 'K10', 'K20')
    hold off
    ylabel('Leadtime (iterations)')
    xlabel('Episodes')
    
    for j = 1:k
        subplot(2,2,3)
        plot(delay_N(2:length+1,1),reward_Ns(:,j,i))
        hold on
    end
    legend('K1', 'K5', 'K10', 'K20')
    hold off
    ylabel('Reward')
    xlabel('Episodes')
    
    for j = 1:k
        subplot(2,2,4)
        plot(delay_N(2:length+1,1),travel_Ns(:,j,i))
        hold on
    end
    legend('K1', 'K5', 'K10', 'K20')
    hold off
    ylabel('Normalised travel distance')
    xlabel('Episodes')
    
    graphtitle = strcat('Metrics for 20 agents, 20 tasks, varied look-ahead parameter and controlled individual queue, n = ',ns{i});
    pol = strcat('N = ', ns{i});
    sgtitle(graphtitle)
end