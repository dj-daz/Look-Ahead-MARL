function [smoothed] = exp_smooth(alpha, to_smooth)
    %   Returns the smoothed values as per the exponential smoothing
    %   function
    %   alpha - smoothing constant between 0.1 and 1
    %   to_smooth - an array containing the raw values
    
    length = size(to_smooth);
    smoothed = zeros(length);
    
    B = to_smooth(1);
    
    for i = 1:length
        smoothed(i) = (alpha*to_smooth(i)) + ((1-alpha)*B);
        B = smoothed(i);
    end
    
end